from .T_S_I_V_ import table_T_S_I_V_


class table_T_S_I_B_(table_T_S_I_V_):
    pass
